from django.apps import AppConfig


class PricingModuleConfig(AppConfig):
    name = 'pricing_module'
