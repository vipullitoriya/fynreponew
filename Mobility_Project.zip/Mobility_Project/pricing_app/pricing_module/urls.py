# pricing_module/urls.py
from django.urls import path
from . import views
from .views import PricingCalculation

urlpatterns = [
    path('', views.list_pricing_configs, name='list_pricing_configs'),
    path('config/create/', views.create_pricing_config, name='create_pricing_config'),
    path('config/edit/<int:config_id>/', views.edit_pricing_config, name='edit_pricing_config'),
    path('config/delete/<int:config_id>/', views.delete_pricing_config, name='delete_pricing_config'),
    path('calculate-price/', PricingCalculation.as_view(), name='calculate_price'),
]
