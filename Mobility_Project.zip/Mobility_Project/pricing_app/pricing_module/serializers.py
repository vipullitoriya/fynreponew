# pricing_module/serializers.py
from rest_framework import serializers

class PricingCalculationSerializer(serializers.Serializer):
    distance_km = serializers.DecimalField(max_digits=5, decimal_places=2)
    time_hours = serializers.DecimalField(max_digits=4, decimal_places=2)
    waiting_minutes = serializers.IntegerField()
