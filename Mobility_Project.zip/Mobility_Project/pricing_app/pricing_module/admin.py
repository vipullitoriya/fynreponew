# pricing_module/admin.py
from django.contrib import admin
from .models import PricingConfig, DistanceBasePrice, DistanceAdditionalPrice, TimeMultiplierFactor, WaitingCharges, DayOfWeek, PricingConfigChangeLog

admin.site.register(PricingConfig)
admin.site.register(DistanceBasePrice)
admin.site.register(DistanceAdditionalPrice)
admin.site.register(TimeMultiplierFactor)
admin.site.register(WaitingCharges)
admin.site.register(DayOfWeek)
admin.site.register(PricingConfigChangeLog)
