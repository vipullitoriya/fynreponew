from django.shortcuts import render, redirect, get_object_or_404
from .models import PricingConfig, log_change
from .forms import PricingConfigForm
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from .serializers import PricingCalculationSerializer
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from django.http import HttpResponse
from decimal import Decimal

# The view function for listing pricing configurations
def list_pricing_configs(request):
    pricing_configs = PricingConfig.objects.all()
    return render(request, 'pricing_module/pricing_config_list.html', {'pricing_configs': pricing_configs})
# @login_required
def create_pricing_config(request):
    if request.method == 'POST':
        form = PricingConfigForm(request.POST)
        if form.is_valid():
            pricing_config = form.save(commit=False)
            
            # Check if the user is authenticated
            if request.user.is_authenticated:
                # If authenticated, use the authenticated user
                pricing_config.user = request.user
            else:
                # If unauthenticated, create an anonymous user
                anonymous_user = authenticate(request, username='anonymous', password='password')
                if anonymous_user is not None:
                    login(request, anonymous_user)
                    pricing_config.user = anonymous_user
                else:
                    # Handle the case where the anonymous user doesn't exist
                    pass
            
            pricing_config.save()
            # Log the change with the authenticated or anonymous user and timestamp
            log_change(pricing_config.user, 'Created', pricing_config)
            return redirect('list_pricing_configs')
    else:
        form = PricingConfigForm()
    return render(request, 'pricing_module/pricing_config_form.html', {'form': form})

def edit_pricing_config(request, config_id):
    pricing_config = get_object_or_404(PricingConfig, pk=config_id)
    if request.method == 'POST':
        form = PricingConfigForm(request.POST, instance=pricing_config)
        if form.is_valid():
            pricing_config = form.save()
            # Log the change with user and timestamp
            log_change(request.user, 'Modified', pricing_config)
            return redirect('list_pricing_configs')
    else:
        form = PricingConfigForm(instance=pricing_config)
    return render(request, 'pricing_module/pricing_config_form.html', {'form': form})

# def delete_pricing_config(request, config_id):
#     pricing_config = get_object_or_404(PricingConfig, pk=config_id)
#     if request.method == 'POST':
#         pricing_config.delete()
#         # Log the change with user and timestamp
#         log_change(request.user, 'Deleted', pricing_config)
#     return redirect('list_pricing_configs')
@login_required  # Add the login_required decorator
def delete_pricing_config(request, config_id):
    pricing_config = get_object_or_404(PricingConfig, pk=config_id)
    if request.method == 'POST':
        if request.user == pricing_config.user:
            # Check if the authenticated user is the owner of the pricing configuration
            pricing_config.delete()
            # Log the change with user and timestamp
            log_change(request.user, 'Deleted', pricing_config)
        else:
            # Handle the case where the authenticated user is not the owner
            return HttpResponse("You do not have permission to delete this configuration.")
    return redirect('list_pricing_configs')

class PricingCalculation(APIView):
    def post(self, request, format=None):
        serializer = PricingCalculationSerializer(data=request.data)
        if serializer.is_valid():
            data = serializer.validated_data
            # Extract input data
            distance_km = data['distance_km']
            time_hours = data['time_hours']
            waiting_minutes = data['waiting_minutes']
            
            # Use the provided formula to calculate the price
            DBP = Decimal('80.00')  # Example base price based on distance
            DAP = Decimal('30.00')  # Example additional price per kilometer
            TMF = Decimal('1.25')  # Example time multiplier factor
            WC = Decimal('5.00')   # Example waiting charges
            
            price = (DBP + (distance_km * DAP)) + (time_hours * TMF) + WC
            
            return Response({'price': price}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
