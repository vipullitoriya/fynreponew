from django.db import models
from django.contrib.auth.models import User  # Import the User model
from django.utils import timezone

class PricingConfig(models.Model):
    name = models.CharField(max_length=100)
    is_active = models.BooleanField(default=False)  # To enable/disable this config
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.name

class DistanceBasePrice(models.Model):
    config = models.ForeignKey(PricingConfig, on_delete=models.CASCADE)
    max_distance_km = models.DecimalField(max_digits=5, decimal_places=2)
    price = models.DecimalField(max_digits=6, decimal_places=2)
    days_of_week = models.ManyToManyField('DayOfWeek')
    
    def __str__(self):
        return f"DBP: {self.price} Rs for up to {self.max_distance_km} KM on {', '.join([str(day) for day in self.days_of_week.all()])}"

class DistanceAdditionalPrice(models.Model):
    config = models.ForeignKey(PricingConfig, on_delete=models.CASCADE)
    per_km_price = models.DecimalField(max_digits=5, decimal_places=2)
    
    def __str__(self):
        return f"DAP: {self.per_km_price} Rs per KM"

class TimeMultiplierFactor(models.Model):
    config = models.ForeignKey(PricingConfig, on_delete=models.CASCADE)
    max_hours = models.DecimalField(max_digits=4, decimal_places=2)
    multiplier = models.DecimalField(max_digits=4, decimal_places=2)
    
    def __str__(self):
        return f"TMF: {self.multiplier}x for up to {self.max_hours} hours"

class WaitingCharges(models.Model):
    config = models.ForeignKey(PricingConfig, on_delete=models.CASCADE)
    initial_waiting_time_minutes = models.IntegerField()
    per_minute_charge = models.DecimalField(max_digits=5, decimal_places=2)
    
    def __str__(self):
        return f"WC: {self.per_minute_charge} Rs per {self.initial_waiting_time_minutes} min after initial {self.initial_waiting_time_minutes} min"

class DayOfWeek(models.Model):
    day = models.CharField(max_length=10, unique=True)  # e.g., "Monday", "Tuesday"
    
    def __str__(self):
        return self.day

# Create a model for logging changes (models.py)
class PricingConfigChangeLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    config = models.ForeignKey(PricingConfig, on_delete=models.CASCADE)
    action = models.CharField(max_length=20)  # 'Created', 'Modified', or 'Deleted'
    timestamp = models.DateTimeField(auto_now_add=True)

def log_change(user, action, config):
    PricingConfigChangeLog.objects.create(user=user, config=config, action=action)
